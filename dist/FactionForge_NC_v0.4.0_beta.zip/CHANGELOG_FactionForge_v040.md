# Cambios de FactionForge NC

## 0.4.0 beta

- Se separa el script único de 0.31 en módulos de simulación, guardado, migración, entidades, AMM y convoy.
- Rutas de guardado relativas al sandbox de CET. JSON con dos copias alternas, revisión, comprobación de escritura y recuperación de una copia válida.
- Importación de los estados antiguos sin ejecutarlos como Lua. Se conservan los originales y se bloquean sobrescrituras si no se pueden recuperar datos válidos.
- Formularios de perfiles independientes de los datos guardados. Referencias de hasta 512 bytes y apariencias de hasta 256, sin el recorte general anterior a 48.
- Aceptación de registros AMM con espacios de nombres distintos de `Character.*`, búsqueda de catálogo, consulta y aplicación de apariencias mediante API pública.
- Límites de perfiles también en las importaciones; asignación de conductores de la misma facción, sin duplicados, y eliminación de referencias huérfanas.
- Despliegue escalonado por facción; seguimiento real de solicitudes, eliminación de solicitudes fallidas, retirada con reintentos y cancelación de colas al perder la sesión.
- Panel de convoy visible. Convoy propio experimental: montaje de conductores, comprobación de asiento real, distancia configurable y cancelación de órdenes propias al detener o perder conductor/vehículo.
- Interoperabilidad conservadora con AMM/MultiConvoy: no se escriben sus tablas, adoptan órdenes ajenas ni simula una API que el mod externo no expone.
- Mantenimiento por turno, mejoras de distritos, límite de ataques, bajas simuladas e IA opcional que respeta alianzas y la facción marcada como jugador.
- Ventana ligada al overlay CET, confirmación de borrados, atajos opcionales y mensajes de estado.
- Pruebas de comportamiento en LuaJIT y empaquetado reproducible sin binarios de terceros ni guardados.

Estas funciones siguen pendientes de validación dentro de Cyberpunk; la simulación territorial no introduce guerras visibles en el mundo.
