# FactionForge NC 0.4.0 beta

Mod de facciones para Cyberpunk 2077, basado en el ZIP **FactionForge_NC_v0.31_AMM_Fix_Beta** aportado por el usuario. Interfaz en español para Cyber Engine Tweaks (CET).

Esta versión añade guardado con recuperación, gestión de NPC y coches, apariencias de AMM, convoy propio experimental y una simulación ampliada de territorios, economía y diplomacia. **No se ha ejecutado dentro de Cyberpunk.** Las pruebas automatizadas utilizan LuaJIT con dobles de las API nativas.

## Instalación y actualización desde 0.31

1. Cierra el juego. Conserva una copia de la carpeta `bin/x64/plugins/cyber_engine_tweaks/mods/factionforge` anterior.
2. Extrae **FactionForge_NC_v0.4.0_beta.zip** en la raíz de Cyberpunk 2077, donde están las carpetas `bin`, `r6` y `archive`. Reemplaza `factionforge/init.lua` y añade su carpeta `modules` completa. No basta con copiar solo `init.lua`.
3. Conserva tus archivos `state_v031.lua` y anteriores dentro de `factionforge`. El ZIP no incluye partidas ni estados de ejemplo que puedan reemplazarlos.
4. Comprueba que CET funciona, carga una partida y abre su overlay. La ventana **FactionForge NC 0.4.0 beta** aparece únicamente con el overlay abierto.
5. En CET, asigna opcionalmente las teclas de FactionForge: mostrar/ocultar, avanzar turno, desplegar facción y detener convoy. Ninguna tecla se asigna automáticamente.

No necesitas Python, Lupa ni este repositorio para instalar el ZIP. No incluye DLL, otros mods ni cambios en los archivos de AMM.

## Dependencias y alcance de la comprobación

| Componente | Versión del adjunto | Uso |
| --- | --- | --- |
| CET | 1.38.0; el nombre del ZIP indica juego 2.5 | Requerido para interfaz, Lua y guardado JSON. El adjunto supera el límite de lectura de 32 MiB. |
| Codeware | 1.21.0 | Requerido para generar y retirar entidades reales; sus declaraciones `DynamicEntitySystem` y `DynamicEntitySpec` se comprobaron en el ZIP. |
| RED4ext | 1.31.0 | Cargador de las extensiones nativas, incluido Codeware. |
| Appearance Menu Mod | 2.15.1 | Opcional para la simulación y los spawns manuales; requerido para el catálogo y las apariencias AMM. El adjunto supera 32 MiB; se consultó su API pública del repositorio, cuyo código declara 2.12.5. |
| AMM MultiConvoy | 0.1.0 | Alternativa al convoy integrado. Se revisaron su Lua y sus instrucciones del ZIP. |
| TweakXL / ArchiveXL | 1.12.0 / 1.28.0 | Dependencias del conjunto de mods del usuario; FactionForge no llama directamente a sus API. |
| redscript / Appearance Runtime Plugin | 0.5.32 / 1.5.1 | Pueden ser necesarios para las apariencias u otros mods instalados; FactionForge no los configura. |

Las versiones aportadas identifican los paquetes, pero **no certifican compatibilidad con tu instalación del juego**. Los binarios Windows no se ejecutaron en el entorno Linux. Usa las dependencias exigidas por cada mod para tu versión de Cyberpunk. Una DLL o un paquete más reciente no corrige por sí solo los errores de un script Lua.

API pública de AMM consultada: `MaximiliumM/appearancemenumod`, commit `54272353d7e4a5c85ab32248eff3c2d8d2541cd7`, archivos `Collabs/API.lua`, `Modules/spawn.lua` y `Modules/scan.lua`. La adaptación de seguimiento también se contrastó con el MultiConvoy aportado. No se redistribuyen sus archivos ni binarios.

## Uso

### Facciones, territorios y economía

Selecciona la facción activa en la cabecera. Puedes crear hasta 30 facciones, editar sus datos, negociar relaciones y consultar sus ingresos. Los tipos y colores son información de la simulación.

Los créditos son internos: **no son eurodólares de V**. Cada turno aporta 10 créditos base + 8 por distrito + 5 por nivel de distrito. El mantenimiento es `floor(miembros / 6) + defensa - 1`. Si el balance final es negativo, los créditos quedan en cero y un miembro abandona la facción.

Reclutar 3 miembros cuesta 30 y mejorar la defensa cuesta 70, hasta nivel 10. Los miembros simulados no generan automáticamente NPC físicos. Cada distrito admite tres mejoras, con costes de 60, 120 y 180 créditos; sus niveles se conservan al cambiar de dueño.

Un ataque cuesta 25 créditos, exige al menos 3 miembros y solo se permite una vez por facción y turno. Fuerza, prestigio, defensa, mejoras y azar intervienen en el resultado. Puede haber bajas simuladas en ambos bandos. Una alianza impide atacar al aliado; atacar a otra facción establece rivalidad. No se cambian las bandas ni los encuentros del juego.

La **IA está desactivada inicialmente**. Al activarla, cada pulsación de avanzar turno permite a las facciones ajenas a la marcada como «mi facción» reclutar y disputar un distrito libre o rival. Puede conquistar tus territorios si sois rivales. No hay turnos automáticos en tiempo real. El editor de asignación manual de distritos está separado y desactivado inicialmente.

### NPC, coches y apariencias

- En el panel 8, pulsa **Leer catálogo AMM**, busca por nombre o registro e importa un personaje a la facción activa. Los registros de AMM con otros espacios de nombres se conservan completos.
- En el panel 5, guarda o edita perfiles. También puedes introducir manualmente un registro TweakDB de personaje o una ruta `.ent` relativa válida. Los nombres de personaje visibles en AMM no son registros TweakDB.
- El panel 6 permite guardar coches, por ejemplo mediante un registro `Vehicle.*` existente. Asigna un NPC distinto de la misma facción a cada conductor. Al borrar un NPC se elimina su asignación como conductor.
- En el panel 7, despliega los perfiles de la facción de forma escalonada. Los límites globales son **6 NPC y 5 coches**, contando solicitudes pendientes. Un mismo perfil no se genera dos veces a la vez. Para generar clones, duplica primero el perfil.
- Usa una zona abierta. Las posiciones dependen de la orientación de V, pero no se comprueban el suelo, las colisiones ni el ancho de la calle.
- El estado se consulta a Codeware: solicitud pendiente, generando, activa o fuera de carga. Las apariciones que no llegan a activarse en 20 segundos se intentan retirar. Los errores de retirada se conservan para reintentar.
- En el panel 8 puedes consultar apariencias del perfil seleccionado en el panel 5, copiarlas a su formulario y solicitar su aplicación al NPC activo mediante la API pública de AMM. Guarda el perfil para conservar el nombre de apariencia. Las apariencias personalizadas pueden requerir archivos adicionales.

Los cambios de los formularios se aplican al pulsar **Guardar perfil**. Una entidad ya desplegada conserva los datos con los que se creó; para aplicar otros datos de spawn, retírala y vuelve a generarla. Rol, rango, ropa y «comportamiento planificado» son metadatos: no activan IA de combate, patrullas o equipamiento.

### Convoy integrado experimental

1. Guarda NPC y coches en la misma facción, con un conductor único por coche.
2. Despliégalos y espera a que estén activos.
3. En el panel 9, pulsa **Montar conductores del garaje**. Espera a verlos en el asiento delantero izquierdo. Si la orden no termina en 20 segundos, se solicita su cancelación.
4. Sube V a **otro** coche y pulsa **Iniciar convoy FactionForge**. Se comprueba el asiento real del conductor antes de dar la orden de seguimiento.
5. Pulsa **Detener convoy FactionForge** para cancelar sus órdenes. El seguimiento también se cancela cuando V sale del coche o se pierde el conductor. Una cancelación no confirmada se conserva y se vuelve a intentar.

Solo se controlan NPC y coches generados por esta instancia de FactionForge. Se usan órdenes nativas de seguimiento con una distancia mínima configurable de 5 a 30 metros; no hay formación, selección de rutas ni sistema propio de tráfico o evasión.

**No uses dos controladores sobre el mismo coche.** FactionForge rechaza un coche que ya tenga una orden de seguimiento ajena y no adopta ni cancela órdenes de AMM/MultiConvoy. Si prefieres MultiConvoy, detén el convoy integrado, asigna asientos desde AMM y usa los atajos **Convoy: Start / Refresh** y **Convoy: Stop** del mod externo. FactionForge no escribe `AMM.Scan.drivers` ni accede a los atajos privados de MultiConvoy.

## Guardado y recuperación

Los datos se guardan en la carpeta de este mod, con rutas relativas al sandbox de CET:

- `state_v040_a.json`
- `state_v040_b.json`

Cada operación válida alterna entre las dos copias, comprueba la escritura mediante lectura y aumenta una revisión. Al iniciar, se carga la revisión válida más reciente. Una escritura fallida deja la anterior disponible y se muestra **HAY CAMBIOS SIN GUARDAR EN DISCO**. Esto permite recuperación ante escrituras incompletas; no sustituye una copia externa.

Si todavía no hay JSON, se importa el primer archivo anterior presente en este orden: `state_v031.lua`, `state_v03.lua`, `state_v022.lua`, `state_v021.lua`, `state_v02.lua`, `state.lua`. Solo se acepta el formato de tablas literales escrito por esas versiones; **no se ejecuta el contenido Lua del guardado**. Los archivos originales quedan intactos. Un archivo antiguo presente pero inválido bloquea el guardado para evitar perder datos; no se ignora silenciosamente para cargar una versión anterior.

Si ningún JSON presente es válido, tampoco se sobrescribe con valores de fábrica. Cierra el juego, conserva ambos archivos fuera de la carpeta del mod y revisa las copias. Para restaurar una copia buena, coloca esa copia con uno de los dos nombres anteriores. Para reiniciar o reimportar un estado antiguo, mueve primero ambos JSON fuera de la carpeta, conservando una copia de seguridad. El mod vuelve a comprobar los archivos al reiniciarse.

Las facciones son compartidas entre las partidas que uses con esta instalación del mod. **Los NPC, los coches, las colas y las órdenes de convoy no forman parte de ese guardado**, y los spawns no se configuran para persistir en las partidas de Cyberpunk. El cambio de personaje/sesión cancela la cola; se comprueban los identificadores y el estado real de las entidades. Retira tus entidades antes de cambiar de partida cuando sea posible.

Para volver a 0.31, restaura la carpeta que conservaste: los JSON nuevos no se importan hacia versiones anteriores. Conserva también los JSON si quieres recuperar luego el progreso de 0.4.0.

## Comprobación dentro del juego pendiente

Antes de considerar esta beta compatible con tu instalación:

1. Comprueba que CET, RED4ext, Codeware y AMM arrancan sin errores. Revisa `cyber_engine_tweaks.log` y el `factionforge.log` que CET genere para el mod.
2. Con una copia de tus datos 0.31, verifica facciones, perfiles, garaje e importación; guarda, reinicia y comprueba que se conserva el estado. Confirma que siguen existiendo los archivos antiguos.
3. Importa un personaje de AMM con un registro largo, genera un NPC y un coche y comprueba que el panel 7 pasa de pendiente a activo. Prueba una apariencia que sepas que está instalada y después retira las entidades.
4. Despliega dos parejas de NPC/coche, asigna dos conductores, móntalos y prueba el convoy desde el coche de V. Comprueba parada, salida de V, desmontaje del conductor y retirada. Haz esta prueba con el convoy de AMM/MultiConvoy detenido.
5. Avanza un turno con IA desactivada y verifica ingreso y mantenimiento. Prueba una mejora, un ataque, su límite por turno y una alianza. Activa después la IA solo si quieres que altere los territorios simulados.
6. Carga otra partida y comprueba que no se restaura una cola de despliegue ni se acumulan spawns.

No se han verificado dentro del juego: carga de DLL, disponibilidad exacta de las API en AMM 2.15.1, navegación de vehículos, animaciones de montaje, colisiones, apariencias y limpieza durante transiciones reales de partida.

## Desarrollo y pruebas

La estructura `bin/` es la que se instala en el juego. Los módulos separan simulación, almacenamiento, importación antigua, Codeware, AMM y convoy; `init.lua` contiene la interfaz y los eventos de CET.

```bash
python3 -m venv .venv
.venv/bin/pip install -r requirements-dev.txt
.venv/bin/python -m unittest discover -s tests -v
.venv/bin/python tools/package_mod.py
```

Las pruebas usan LuaJIT 2.1. Incluyen migración, recuperación de escritura incompleta, límites, datos corruptos, economía, diplomacia, IA, gestión de entidades, dobles de AMM, órdenes de montaje/seguimiento y renderizado de los nueve paneles. Los dobles permiten comprobar las decisiones del Lua sin afirmar que las API nativas funcionan en el juego.

El ZIP instalable y su SHA-256 se generan en `dist/`. El empaquetador usa una lista explícita de archivos y excluye dependencias, tests y estados personales.

## Desinstalación

Detén el convoy, retira las entidades, cierra el juego y conserva tus estados si quieres recuperarlos. Elimina solo `bin/x64/plugins/cyber_engine_tweaks/mods/factionforge`. No se modifica ni se elimina otro mod.
